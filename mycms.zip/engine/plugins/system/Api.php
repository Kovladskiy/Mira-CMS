<?php
$plugin_name = 'Api';
class Api extends MiraCMS {
    public function __construct() {
        
    }


}
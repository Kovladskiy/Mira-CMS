<?php
$plugin_name = 'Security';
class Security extends MiraCMS {

}
